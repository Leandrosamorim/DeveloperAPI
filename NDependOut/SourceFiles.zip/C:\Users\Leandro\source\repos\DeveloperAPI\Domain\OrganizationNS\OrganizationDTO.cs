﻿

namespace Domain.OrganizationNS
{
    public class OrganizationDTO
    {
        public Guid UId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
